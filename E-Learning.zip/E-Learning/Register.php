<?php include('path.php'); ?>
<?php include(ROOT_PATH . "/app/controllers/users.php"); ?>
<html>

<head>

	<!-- font Awesome -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" integrity="sha384-v8BU367qNbs/aIZIxuivaU55N5GPF89WBerHoGA4QTcbUjYiLQtKdrfXnqAcXyTv" crossorigin="anonymous">

	<!--Google Font -->
<link href="https://fonts.googleapis.com/css2?family=Candal&family=Lora:wght@700&display=swap" rel="stylesheet">
	<!--custom style -->
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">

	<title>Register</title>
</head>

<body>


	<?php include(ROOT_PATH . "/app/includes/header.php"); ?>

	<div class="auth-content">

		<form action="Register.php" method="post">
			<h2 class="form-title">Register</h2>

			<?php include(ROOT_PATH . "/app/helpers/formsErrors.php"); ?>

			<div>
				<label>username</label>
				<input type="text" name="name" value="<?php echo $username; ?>" class="text-input">
				</>
				<div>
					<label>email</label>
					<input type="email" name="email" value="<?php echo $email; ?>" class=" text-input">
				</div>

				<div>
					<label>password</label>
					<input type="password" name="password" value="<?php echo $password; ?>" class=" text-input">
				</div>
				<div>
					<label>Conform password</label>
					<input type="password" name=" passwordConf" value="<?php echo $passwordConf; ?>" class=" text-input">
				</div>
				<div>
					<button type="submit" name="register-btn" class="btn btn -big">Register</button>

				</div>
				<p><a href="<?php echo BASE_URL . '/login.php' ?>">Or Sign In</a></p>
		</form>
	</div>


	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

	<script src="assets/js/script.js"></script>


</body>

</html>