<?php include('path.php');

include(ROOT_PATH . "/app/database/db.php");


?>
<html>

<head>
	<!-- font Awesome -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" integrity="sha384-v8BU367qNbs/aIZIxuivaU55N5GPF89WBerHoGA4QTcbUjYiLQtKdrfXnqAcXyTv" crossorigin="anonymous">

	<!--Google Forms -->

<link href="https://fonts.googleapis.com/css2?family=Candal&family=Lora:wght@700&display=swap" rel="stylesheet">

	<!--custom style -->
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<title>blog</title>

</head>

<body>
	<?php include(ROOT_PATH . "/app/includes/header.php"); ?>
	<?php include(ROOT_PATH . "/app/includes/messages.php"); ?>



	<!--Page Wrapper-->
	<div class="page-wrapper">


		<!--Post Slider-->
		<div class="post-slider">
			<h1 class="slider-title">Trending Post</h1>
			<i class="fas fa-chevron-left prev"></i>
			<i class="fas fa-chevron-right next"></i>
			<div class="post-wrapper">
				<div class="post">
					<img src="assets/images/1.jpg" alt="" class="slider-image">
					<div class="post-info">
						<h4><a href="single.html">PHP is the one of web Application it is used for develop the webside</a></h4>
						<i class="far fa-user">Abdullah</i>
						&nbsp;
						<i class="far fa-calendar">Mar 20, 2020</i>
					</div>
				</div>

				<div class="post">
					<img src="assets/images/1.jpg" alt="" class="slider-image">
					<div class="post-info">
						<h4><a href="single.html">PHP is the one of web Application it is used for develop the webside</a></h4>
						<i class="far fa-user">Abdullah</i>
						&nbsp;
						<i class="far fa-calendar">Mar 20, 2020</i>
					</div>
				</div>

				<div class="post">
					<img src="assets/images/1.jpg" alt="" class="slider-image">
					<div class="post-info">
						<h4><a href="single.html">PHP is the one of web Application it is used for develop the webside</a></h4>
						<i class="far fa-user">Abdullah</i>
						&nbsp;
						<i class="far fa-calendar">Mar 20, 2020</i>
					</div>
				</div>

				<div class="post">
					<img src="assets/images/1.jpg" alt="" class="slider-image">
					<div class="post-info">
						<h4><a href="single.html">PHP is the one of web Application it is used for develop the webside</a></h4>
						<i class="far fa-user">Abdullah</i>
						&nbsp;
						<i class="far fa-calendar">Mar 20, 2020</i>
					</div>
				</div>

				<div class="post">
					<img src="assets/images/1.jpg" alt="" class="slider-image">
					<div class="post-info">
						<h4><a href="single.html">PHP is the one of web Application it is used for develop the webside</a></h4>
						<i class="far fa-user">Abdullah</i>
						&nbsp;
						<i class="far fa-calendar">Mar 20, 2020</i>
					</div>
				</div>

				<div class="post">
					<img src="assets/images/1.jpg" alt="" class="slider-image">
					<div class="post-info">
						<h4><a href="single.html">PHP is the one of web Application it is used for develop the webside</a></h4>
						<i class="far fa-user">Abdullah</i>
						&nbsp;
						<i class="far fa-calendar">Mar 20, 2020</i>
					</div>
				</div>
			</div>
		</div>
		<!--//Post Slider-->

		<!--content -->
		<div class="content clearfix">
			<!--main content-->
			<div class="main-content">
				<h1 class="recent-post-title">Recent Post</h1>
				<div class="post">
					<img src="assets/images/2.jpg" alt="" class="post-image">
					<div class="post-preview">
						<h1><a href="single.html">PHP is the one of web Application it is used for develop console Application</a></h1>
						<i class="far fa-user">Abdullah</i>
						&nbsp;
						<i class="far calendar">Mar 20,2020</i>
						<p class="preview-text">
							The Programming is very Important Knowledge for
							us We shoud be learn in this Language.
						</p>
						<a href="single.html" class="btn read-more">Read More</a>
					</div>
				</div>
				<div class="post">
					<img src="assets/images/2.jpg" alt="" class="post-image">
					<div class="post-preview">
						<h1><a href="single.html">PHP is the one of web Application it is used for develop console Application</a></h1>
						<i class="far fa-user">Abdullah</i>
						&nbsp;
						<i class="far calendar">Mar 20,2020</i>
						<p class="preview-text">
							The Programming is very Important Knowledge for
							us We shoud be learn in this Language.
						</p>
						<a href="single.html" class="btn read-more">Read More</a>
					</div>
				</div>

				<div class="post">
					<img src="assets/images/2.jpg" alt="" class="post-image">
					<div class="post-preview">
						<h1><a href="single.html">PHP is the one of web Application it is used for develop console Application</a></h1>
						<i class="far fa-user">Abdullah</i>
						&nbsp;
						<i class="far calendar">Mar 20,2020</i>
						<p class="preview-text">
							The Programming is very Important Knowledge for
							us We shoud be learn in this Language.
						</p>
						<a href="single.html" class="btn read-more">Read More</a>
					</div>
				</div>
				<div class="post">
					<img src="assets/images/2.jpg" alt="" class="post-image">
					<div class="post-preview">
						<h1><a href="single.html">PHP is the one of web Application it is used for develop console Application</a></h1>
						<i class="far fa-user">Abdullah</i>
						&nbsp;
						<i class="far calendar">Mar 20,2020</i>
						<p class="preview-text">
							The Programming is very Important Knowledge for
							us We shoud be learn in this Language.
						</p>
						<a href="single.html" class="btn read-more">Read More</a>
					</div>
				</div>
				<div class="post">
					<img src="assets/images/2.jpg" alt="" class="post-image">
					<div class="post-preview">
						<h1><a href="single.html">PHP is the one of web Application it is used for develop console Application</a></h1>
						<i class="far fa-user">Abdullah</i>
						&nbsp;
						<i class="far calendar">Mar 20,2020</i>
						<p class="preview-text">
							The Programming is very Important Knowledge for
							us We shoud be learn in this Language.
						</p>
						<a href="single.html" class="btn read-more">Read More</a>
					</div>
				</div>
			</div>

			<!--//main content-->
			<div class="sidebar">
				<div class="section search">
					<h2 class="section-title">Search</h2>
					<form action="index.html" method="post">
						<input type="text" name="search-term" class="text-input" placeholder="search...">
					</form>
				</div>

				<div class="section topics">
					<h2 class="section-title">Topics</h2>
					<ul>
						<li><a href="#">Poems</a></li>
						<li><a href="#">Quotes</a></li>
						<li><a href="#">Fiction</a></li>
						<li><a href="#">Biography</a></li>
						<li><a href="#">Motivation</a></li>
					</ul>
				</div>
			</div>
		</div>
		<!--//content -->

	</div>
	<!--Page Wrapper-->
	<!--footer-->
	<?php include(ROOT_PATH . "/app/includes/footer.php"); ?>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

	<!-- slick -->
	<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

	<script src="assets/js/script.js"></script>


</body>

</html>