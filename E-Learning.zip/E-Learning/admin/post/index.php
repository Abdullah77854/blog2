<?php include('../../path.php') ?>
<html>

<head>
	<!-- font Awesome -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" integrity="sha384-v8BU367qNbs/aIZIxuivaU55N5GPF89WBerHoGA4QTcbUjYiLQtKdrfXnqAcXyTv" crossorigin="anonymous">

	<!--Google Font -->
	<link href="https://fonts.googleapis.com/css2?family=Candal&family=Lora:wght@700&display=swap" rel="stylesheet">

	<!--custom style -->
	<link rel="stylesheet" type="text/css" href="../../assets/css/style.css">

	<!--Admin style -->
	<link rel="stylesheet" type="text/css" href="../../assets/css/admin.css">
	<title>Admin Section - Manage Posts</title>

</head>

<body>
	<header>
		<a class="logo" href="<?php echo BASE_URL . '/index.php'; ?>">
			<h1 class=" logo-text"><span>Awa</span>Inspires</h1>
		</a>
		<i class="fa fa-bars menue-toggle"></i>
		<ul class="nav">

			<!--<li><a href="#">Sigup</a></li>
		<li><a href="#">Login</a></li>-->
			<li>
				<a href="#">
					<i class="fa fa-user"></i>
					Awa Melvine
					<i class="fa fa-chevron-down"></i>
				</a>
				<ul>
					<li><a href="#">Dashboard</a></li>
					<li><a href="#" class="logout">Logout</a></li>
				</ul>
			</li>
		</ul>
	</header>

	<!-- Admin Page Wrapper-->
	<div class="admin-wrapper">

		<!--left sidebar-->
		<div class="left-sidebar">
			<ul>
				<li><a href="<?php echo BASE_URL . '/admin/post/index.php'; ?>">Manage Posts</a></li>
				<li><a href=" <?php echo BASE_URL . '/admin/users/index.php'; ?>">Manage Users</a> </li>
				<li><a href=" <?php echo BASE_URL . '/admin/topics/index.php'; ?>">Manage Topics</a></li>

			</ul>
		</div>
	
		<!--//left sidebar-->

		<!--Admin Content-->
		<div class="admin-content">
			<div class="button-group">
				<a href="create.php " class="btn btn-big">Add Post</a>
				<a href="index.php" class="btn btn-big">Manage Post</a>
			</div>

			<div class="content">
				<h2 class="page-title">Manage Post</h2>

				<table>
					<thead>
						<th>SN</th>
						<th>Title</th>
						<th>Author</th>
						<th colspan="3">Action</th>
					</thead>
					<tbody>
						<tr>
							<td>1</td>
							<td>This is First Post</td>
							<td>Abdu</td>
							<td><a href="#" class="Edit">Edit</a></td>
							<td><a href="#" class="Delete">Delete</a></td>
							<td><a href="#" class="Publish">Publish</a></td>
						</tr>

						<tr>
							<td>2</td>
							<td>This is Second Post</td>
							<td>Abdu</td>
							<td><a href="#" class="Edit">Edit</a></td>
							<td><a href="#" class="Delete">Delete</a></td>
							<td><a href="#" class="Publish">Publish</a></td>
						</tr>
					</tbody>
				</table>
			</div>

		</div>
		<!--//Admin Content-->
	</div>
	<!--Page Wrapper-->



	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>


	<script src="../../js/script.js"></script>


</body>

</html>