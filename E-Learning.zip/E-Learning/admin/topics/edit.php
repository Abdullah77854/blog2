<?php include('../../path.php'); ?>
<html>

  <head>
    <!-- font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" integrity="sha384-v8BU367qNbs/aIZIxuivaU55N5GPF89WBerHoGA4QTcbUjYiLQtKdrfXnqAcXyTv" crossorigin="anonymous">

    <!--Google Forms -->
    <link href="https://fonts.googleapis.com/css2?family=Candal&family=Lora:wght@700&display=swap" rel="stylesheet">
    <!--custom style -->
    <link rel="stylesheet" type="text/css" href="../../assets/css/style.css">

    <!--Admin style -->
    <link rel="stylesheet" type="text/css" href="../../assets/css/admin.css">
    <title>Admin Section - Edit Topic</title>

  </head>

  <body>

    <!-- admin header-->
    <header>
      <a class="logo" href="<?php echo BASE_URL . '/index.php'; ?>">
        <h1 class="logo-text"><span>Awa</span>Inspires</h1>
      </a>
      <i class="fa fa-bars menue-toggle"></i>
      <ul class="nav">
        <li>
          <a href="#">
            <i class="fa fa-user"></i>
            Awa Melvine
            <i class="fa fa-chevron-down"></i>
          </a>
          <ul>
            <li><a href="#" class="logout">Logout</a></li>
          </ul>
        </li>
      </ul>
    </header>

    <!-- Admin Page Wrapper-->
    <div class="admin-wrapper">
      <div class="left-sidebar">
        <ul>
          <li><a href="<?php echo BASE_URL . '/admin/post/index.php'; ?>">Manage Posts</a></li>
          <li><a href="<?php echo BASE_URL . '/admin/users/index.php'; ?>">Manage Users</a></li>
          <li><a href=" <?php echo BASE_URL . '/admin/topics/index.php'; ?>">Manage Topics</a></li>

        </ul>
      </div>


      <!--Admin Content-->
      <div class=" admin-content">
        <div class="button-group">
          <a href="create.php" class="btn btn-big">Add Topics</a>
          <a href="index.php" class="btn btn-big">Manage Topics</a>
        </div>
        <div class="content">
          <h2 class="page-title">Add Topics</h2>
          <form action="create.php" method="post">
            <div>
              <label>Name</label>
              <input type="text" name="name" class="text-input">
            </div>
            <div>
              <label>Description</label>
              <textarea name="Description" id="body"></textarea>
            </div>

            <div>
              <button type="submit" class="btn btn-big">Update Topics</button>
            </div>
          </form>


        </div>
      </div>
      <!--//Admin Content-->
    </div>
    <!--Page Wrapper-->


    <!--jquery-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!--ckeditor-->
    <script src="https://cdn.ckeditor.com/ckeditor5/19.1.1/classic/ckeditor.js"></script>
    <!-- custom script-->
    <script src="../../assets/js2/script.js"></script>


  </body>

</html>