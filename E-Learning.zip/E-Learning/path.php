<?php
define("ROOT_PATH", $_SERVER["DOCUMENT_ROOT"] . "/e-learning/");
define("BASE_URL", "http://localhost/E-Learning"); 

